<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1>Detalle del Producto</h1>
                    <div>
                        <a href="<?php echo e(route('tienda.edit', $tienda)); ?>" class="btn btn-warning">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        <a href="<?php echo e(route('tienda.index')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Imagen del Producto</h5>
                            </div>
                            <div class="card-body text-center">
                                <?php if($tienda->img_url): ?>
                                    <img src="<?php echo e(asset('storage/' . $tienda->img_url)); ?>" alt="<?php echo e($tienda->nombre); ?>"
                                        class="img-fluid rounded shadow" style="max-height: 400px;">
                                <?php else: ?>
                                    <div class="bg-secondary text-white d-flex align-items-center justify-content-center rounded"
                                        style="height: 300px;">
                                        <div class="text-center">
                                            <i class="fas fa-image fa-3x mb-2"></i>
                                            <p class="mb-0">Sin imagen disponible</p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Información del Producto</h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <td class="fw-bold">ID:</td>
                                            <td><?php echo e($tienda->id); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold">Nombre:</td>
                                            <td><?php echo e($tienda->nombre); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold">Precio:</td>
                                            <td class="text-success fw-bold">$<?php echo e(number_format($tienda->precio, 2)); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold">Stock:</td>
                                            <td>
                                                <span
                                                    class="badge <?php echo e($tienda->cantidad > 0 ? 'bg-success' : 'bg-danger'); ?> fs-6">
                                                    <?php echo e($tienda->cantidad); ?> unidades
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold">Estado:</td>
                                            <td>
                                                <?php if($tienda->cantidad > 10): ?>
                                                    <span class="badge bg-success">En Stock</span>
                                                <?php elseif($tienda->cantidad > 0): ?>
                                                    <span class="badge bg-warning">Stock Bajo</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Agotado</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold">Creado:</td>
                                            <td><?php echo e($tienda->created_at->format('d/m/Y H:i:s')); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold">Última actualización:</td>
                                            <td><?php echo e($tienda->updated_at->format('d/m/Y H:i:s')); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="card mt-3">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Acciones</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <a href="<?php echo e(route('tienda.edit', $tienda)); ?>" class="btn btn-warning">
                                        <i class="fas fa-edit"></i> Editar Producto
                                    </a>
                                    <form action="<?php echo e(route('tienda.destroy', $tienda)); ?>" method="POST"
                                        onsubmit="return confirm('¿Estás seguro de eliminar este producto? Esta acción no se puede deshacer.')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger w-100">
                                            <i class="fas fa-trash"></i> Eliminar Producto
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Antonio\Documents\vendeyapuestaBack\resources\views\tienda\show.blade.php ENDPATH**/ ?>