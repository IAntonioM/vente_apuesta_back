<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1>Gestión de Tienda</h1>
                    <a href="<?php echo e(route('tienda.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Agregar Producto
                    </a>
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Filtros -->
                <div class="row mb-3">
                    <div class="col-12">
                        <form method="GET" action="<?php echo e(route('tienda.index')); ?>" class="row g-3">
                            <!-- Búsqueda por nombre -->
                            <div class="col-md-3">
                                <label for="nombre" class="form-label">Buscar por nombre</label>
                                <input type="text" class="form-control" id="nombre" name="nombre"
                                    placeholder="Buscar producto..." value="<?php echo e(request('nombre')); ?>">
                            </div>

                            <!-- Filtro por ronda -->
                            <div class="col-md-2">
                                <label for="n_ronda" class="form-label">Filtrar por Ronda</label>
                                <select class="form-select" id="n_ronda" name="n_ronda">
                                    <option value="">Todas las rondas</option>
                                    <?php for($i = 1; $i <= 15; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php echo e(request('n_ronda') == $i ? 'selected' : ''); ?>>
                                            Ronda <?php echo e($i); ?>

                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>

                            <!-- Filtro por nivel -->
                            <div class="col-md-2">
                                <label for="nivel" class="form-label">Filtrar por Nivel</label>
                                <select class="form-select" id="nivel" name="nivel">
                                    <option value="">Todos los niveles</option>
                                    <?php for($i = 1; $i <= 10; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php echo e(request('nivel') == $i ? 'selected' : ''); ?>>
                                            Nivel <?php echo e($i); ?>

                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>

                            <!-- Filtro por mayor/menor -->
                            <div class="col-md-3">
                                <label for="flag_mayor" class="form-label">Mayor a su Ronda</label>
                                <select class="form-select" id="flag_mayor" name="flag_mayor">
                                    <option value="">Todos</option>
                                    <option value="1" <?php echo e(request('flag_mayor') === '1' ? 'selected' : ''); ?>>Si</option>
                                    <option value="0" <?php echo e(request('flag_mayor') === '0' ? 'selected' : ''); ?>>No</option>
                                </select>
                            </div>

                            <!-- Botones -->
                            <div class="col-md-2">
                                <label class="form-label">&nbsp;</label>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-primary" type="submit">
                                        <i class="fas fa-search"></i> Buscar
                                    </button>
                                    <?php if(request()->hasAny(['nombre', 'n_ronda', 'nivel', 'flag_mayor'])): ?>
                                        <a href="<?php echo e(route('tienda.index')); ?>" class="btn btn-outline-secondary">
                                            <i class="fas fa-times"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Indicadores de filtros activos -->
                <?php if(request()->hasAny(['nombre', 'n_ronda', 'nivel', 'flag_mayor'])): ?>
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="d-flex flex-wrap gap-2">
                                <span class="text-muted">Filtros activos:</span>
                                <?php if(request('nombre')): ?>
                                    <span class="badge bg-primary">
                                        Nombre: "<?php echo e(request('nombre')); ?>"
                                        <a href="<?php echo e(request()->fullUrlWithQuery(['nombre' => null])); ?>" class="text-white ms-1">
                                            <i class="fas fa-times"></i>
                                        </a>
                                    </span>
                                <?php endif; ?>
                                <?php if(request('n_ronda')): ?>
                                    <span class="badge bg-info">
                                        Ronda: <?php echo e(request('n_ronda')); ?>

                                        <a href="<?php echo e(request()->fullUrlWithQuery(['n_ronda' => null])); ?>" class="text-white ms-1">
                                            <i class="fas fa-times"></i>
                                        </a>
                                    </span>
                                <?php endif; ?>
                                <?php if(request('nivel')): ?>
                                    <span class="badge bg-warning">
                                        Nivel: <?php echo e(request('nivel')); ?>

                                        <a href="<?php echo e(request()->fullUrlWithQuery(['nivel' => null])); ?>" class="text-white ms-1">
                                            <i class="fas fa-times"></i>
                                        </a>
                                    </span>
                                <?php endif; ?>
                                <?php if(request('flag_mayor') !== null): ?>
                                    <span class="badge bg-success">
                                        Tipo: <?php echo e(request('flag_mayor') == '1' ? 'Mayor' : 'Menor'); ?>

                                        <a href="<?php echo e(request()->fullUrlWithQuery(['flag_mayor' => null])); ?>" class="text-white ms-1">
                                            <i class="fas fa-times"></i>
                                        </a>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Imagen</th>
                                        <th>Nombre</th>
                                        <th>Precio</th>
                                        <th>Cantidad</th>
                                        <th>Ronda - Nivel</th>
                                        <th>Mayor a su ronda</th>
                                        <th>Ganancia</th>
                                        <th>Creado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($producto->id); ?></td>
                                            <td>
                                                <?php if($producto->img_url): ?>
                                                    <img src="<?php echo e(asset('storage/' . $producto->img_url)); ?>"
                                                        alt="<?php echo e($producto->nombre); ?>" class="img-thumbnail"
                                                        style="width: 50px; height: 50px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="bg-secondary text-white d-flex align-items-center justify-content-center"
                                                        style="width: 50px; height: 50px; border-radius: 0.375rem;">
                                                        Sin imagen
                                                    </div>
                                                <?php endif; ?>
                                            </td>

                                            <td><?php echo e($producto->nombre); ?></td>
                                            <td>$<?php echo e(number_format($producto->precio, 2)); ?></td>
                                            <td>
                                                <span
                                                    class="badge <?php echo e($producto->cantidad > 0 ? 'bg-success' : 'bg-danger'); ?>">
                                                    <?php echo e($producto->cantidad); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-primary">R<?php echo e($producto->n_ronda); ?></span>
                                                <span class="badge bg-secondary">N<?php echo e($producto->nivel); ?></span>
                                            </td>
                                            <td>
                                                <span class="badge <?php echo e($producto->flag_mayor ? 'bg-warning' : 'bg-info'); ?>">
                                                    <?php echo e($producto->flag_mayor ? 'Si' : 'No'); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <?php if($producto->ganancia): ?>
                                                    $<?php echo e(number_format($producto->ganancia, 2)); ?>

                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($producto->created_at->format('d/m/Y H:i')); ?></td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="<?php echo e(route('tienda.show', $producto)); ?>"
                                                        class="btn btn-info btn-sm text-white" title="Ver">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('tienda.edit', $producto)); ?>"
                                                        class="btn btn-warning btn-sm text-dark" title="Editar">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <form action="<?php echo e(route('tienda.destroy', $producto)); ?>" method="POST"
                                                        class="d-inline"
                                                        onsubmit="return confirm('¿Estás seguro de eliminar este producto?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm"
                                                            title="Eliminar">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="9" class="text-center">
                                                <?php if(request()->hasAny(['nombre', 'n_ronda', 'nivel', 'flag_mayor'])): ?>
                                                    No se encontraron productos con los filtros aplicados
                                                    <br>
                                                    <a href="<?php echo e(route('tienda.index')); ?>"
                                                        class="btn btn-sm btn-outline-primary mt-2">
                                                        Ver todos los productos
                                                    </a>
                                                <?php else: ?>
                                                    No hay productos registrados
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Antonio\Documents\vendeyapuestaBack\resources\views\tienda\index.blade.php ENDPATH**/ ?>