<nav class="navbar navbar-light bg-light shadow-sm mb-4">
    <div class="container-fluid d-flex justify-content-between">
        <span class="navbar-text">
            Bienvenido, <strong><?php echo e(Auth::user()->nombres_apellidos); ?></strong>
        </span>

        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-danger btn-sm">Salir</button>
        </form>
    </div>
</nav>
<?php /**PATH C:\Users\Antonio\Documents\vendeyapuestaBack\resources\views/partials/header.blade.php ENDPATH**/ ?>