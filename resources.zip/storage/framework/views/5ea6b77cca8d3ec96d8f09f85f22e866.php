<div class="sidebar p-3">
    
    <h3 class="text-white text-center mb-4">Venta y Apuestas</h3>

    <ul class="nav flex-column">
        
        <li class="nav-item mb-2">
            <a href="<?php echo e(route('principal')); ?>" class="nav-link text-white">🏠 Principal</a>
        </li>

        
        <li class="nav-item mb-2">
            <a href="/tienda" class="nav-link text-white">🛒 Tienda</a>

        </li>

        
        <li class="nav-item">
            <a href="/usuarios" class="nav-link text-white">👥 Usuarios</a>
        </li>
    </ul>
</div>
<?php /**PATH C:\Users\Antonio\Documents\vendeyapuestaBack\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>