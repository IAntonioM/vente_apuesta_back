<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1>Gestión de Tienda</h1>
                    <a href="<?php echo e(route('tienda.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Agregar Producto
                    </a>
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Búsqueda por nombre -->
                <div class="row mb-3">
                    <div class="col-md-6">
                        <form method="GET" action="<?php echo e(route('tienda.index')); ?>">
                            <div class="input-group">
                                <input type="text" class="form-control" name="nombre"
                                       placeholder="Buscar producto por nombre..." value="<?php echo e(request('nombre')); ?>">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-search"></i> Buscar
                                </button>
                                <?php if(request('nombre')): ?>
                                    <a href="<?php echo e(route('tienda.index')); ?>" class="btn btn-outline-secondary">
                                        <i class="fas fa-times"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                    <?php if(request('nombre')): ?>
                        <div class="col-md-6">
                            <div class="d-flex justify-content-end align-items-center">
                                <span class="badge bg-primary">
                                    Filtrado por: "<?php echo e(request('nombre')); ?>"
                                    <a href="<?php echo e(route('tienda.index')); ?>" class="text-white ms-1" title="Limpiar filtro">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Imagen</th>
                                        <th>Nombre</th>
                                        <th>Precio</th>
                                        <th>Cantidad</th>
                                        <th>Creado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($producto->id); ?></td>
                                            <td>
                                                <?php if($producto->img_url): ?>
                                                    <img src="<?php echo e(asset($producto->img_url)); ?>" alt="<?php echo e($producto->nombre); ?>"
                                                        class="img-thumbnail"
                                                        style="width: 50px; height: 50px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="bg-secondary text-white d-flex align-items-center justify-content-center"
                                                        style="width: 50px; height: 50px; border-radius: 0.375rem;">
                                                        Sin imagen
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($producto->nombre); ?></td>
                                            <td>$<?php echo e(number_format($producto->precio, 2)); ?></td>
                                            <td>
                                                <span class="badge <?php echo e($producto->cantidad > 0 ? 'bg-success' : 'bg-danger'); ?>">
                                                    <?php echo e($producto->cantidad); ?>

                                                </span>
                                            </td>
                                            <td><?php echo e($producto->created_at->format('d/m/Y H:i')); ?></td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="<?php echo e(route('tienda.show', $producto)); ?>"
                                                        class="btn btn-info btn-sm text-white" title="Ver">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('tienda.edit', $producto)); ?>"
                                                        class="btn btn-warning btn-sm text-dark" title="Editar">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <form action="<?php echo e(route('tienda.destroy', $producto)); ?>" method="POST"
                                                        class="d-inline"
                                                        onsubmit="return confirm('¿Estás seguro de eliminar este producto?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm"
                                                            title="Eliminar">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="7" class="text-center">
                                                <?php if(request('nombre')): ?>
                                                    No se encontraron productos con el nombre "<?php echo e(request('nombre')); ?>"
                                                    <br>
                                                    <a href="<?php echo e(route('tienda.index')); ?>" class="btn btn-sm btn-outline-primary mt-2">
                                                        Ver todos los productos
                                                    </a>
                                                <?php else: ?>
                                                    No hay productos registrados
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Sin paginación, se muestran todos los productos -->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Antonio\Documents\vendeyapuestaBack\resources\views/tienda/index.blade.php ENDPATH**/ ?>