<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="card-body">
            <h1 class="mb-3">Hola, <?php echo e(Auth::user()->nombres_apellidos); ?> 👋</h1>
            <p>Bienvenido a tu panel de administración.</p>

            <hr>

            <div class="row">
                <div class="col-md-4">
                    <div class="p-3 border rounded bg-light">
                        <h5>Sección 1</h5>
                        <p>Contenido de ejemplo.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-3 border rounded bg-light">
                        <h5>Sección 2</h5>
                        <p>Más contenido de ejemplo.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-3 border rounded bg-light">
                        <h5>Sección 3</h5>
                        <p>Texto adicional aquí.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Antonio\Documents\vendeyapuestaBack\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>